﻿using System;

namespace ConsoleApp1
{
    internal partial class Program
    {
        internal class CarPath : IGetTime
        {
            public int GetTime(double kilometers)
            {
                return Convert.ToInt32(kilometers / 60);
            }
        }
    }
}
