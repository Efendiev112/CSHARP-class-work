﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static ConsoleApp1.Program;

namespace ConsoleApp1
{
    internal partial class Program
    {
        static void Main(string[] args)
        {
            Navigator navigator = new Navigator();

            double path = 55.4;
            Console.WriteLine((navigator.GetNavigate(new CarPath(), path)));
            Console.WriteLine((navigator.GetNavigate(new BicyclePath(), path)));
            Console.WriteLine((navigator.GetNavigate(new WalkerPath(), path)));
            Console.WriteLine((navigator.GetNavigate(new BusPath(), path)));
           


            Console.ReadKey();

        }

    }
}
