﻿namespace ConsoleApp1
{
    internal partial class Program
    {
        internal interface IGetTime
        {
            int GetTime(double kilometers);
        }


    }
}
