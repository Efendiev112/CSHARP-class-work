﻿namespace ConsoleApp1
{
    internal partial class Program
    {
        internal class Navigator
        {
            public int GetNavigate(IGetTime getTime, double km)
            {
                return getTime.GetTime(km);
            }

        }
    }
}
