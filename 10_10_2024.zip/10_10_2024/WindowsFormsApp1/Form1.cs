﻿using System;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            var x = Convert.ToDouble(textBox11.Text);
            double y = Convert.ToDouble(textBox12.Text);

            var sum = x + y;
            double deff = x - y;
            double p = x * y;
            double c = x / y;

            lblSum.Text = lblSum.Text + " " + sum.ToString();
            lblMinus.Text = lblMinus.Text + " " + deff.ToString();
            lblMul.Text = lblMul.Text + " " + p.ToString();
            lblChast.Text = lblChast.Text + " " + c.ToString();

        }

        private void textBox11_TextChanged(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void lblSum_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            double x = Convert.ToDouble(textBox14.Text);
            double y = (Math.Cos(x) + Math.Sin(x)) / (Math.Pow(x, 2) + 3 * x);
            label10.Text = "ЗНАЧЕНИЕ ФУНКЦИИ =\n" + y.ToString();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            double x = Convert.ToDouble(textBox1.Text);
            double y = Math.Sqrt(x + Math.Pow(x, 3) + 1.5) / x + 1;
            label11.Text = "ЗНАЧЕНИЕ ФУНКЦИИ =\n" + y.ToString();
        }
    }
}
