﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace convert
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //var x = Convert.ToDouble(Console.ReadLine());
            //double y = Convert.ToDouble(Console.ReadLine());

            //var sum = x + y;
            //double deff = x - y;
            //double p = x * y;
            //double c = x / y;

            //var sq = Math.Pow(3, 5);

            //Console.WriteLine($"сумма {sum},\n" +
            //                $"разница {deff},\n" +
            //                $"произведение {p},\n" +
            //                $"частное {c},");

            //Console.WriteLine($"степень {sq}");


            Console.WriteLine("Найти длину окружности L и площадь круга S заданного радиуса R: В качестве значения π использовать 3.14.");
            Console.WriteLine("Drizhenko Artem");
            Console.WriteLine("Input radius");
            double R = Convert.ToDouble(Console.ReadLine());

            DlinaOkrujnosti(R);
            Console.WriteLine("\n\n");
            SKruga(R);

            Console.ReadKey();
        }

        public static void DlinaOkrujnosti(double R)
        {
            if (R <= 0)
            {
                throw new Exception("number below zero");
            }
            else
            {
                double Pi = 3.14;
                Console.WriteLine("Калькулятор длины окружности");
                double L = ((2 * Pi) * R);
                Console.WriteLine($"Dlina = {L}");
            }
        }
        public static void SKruga(double R)
        {
            if (R <= 0)
            {
                throw new Exception("number below zero");
            }
            else
            {
                double Pi = 3.14;
                Console.WriteLine("Калькулятор площади круга");
                double S = Pi * Math.Pow(R,2);
                Console.WriteLine($"Площадь = {S}");
            }
        }
    }
}
