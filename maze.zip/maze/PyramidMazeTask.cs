﻿namespace Mazes;

public static class PyramidMazeTask
{

	

}