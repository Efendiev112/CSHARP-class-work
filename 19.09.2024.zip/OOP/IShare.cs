﻿namespace OOP
{
    public interface IShare
    {
        double Area();
    }
}