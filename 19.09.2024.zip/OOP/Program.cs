﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using System.Linq;

namespace OOP
{
    internal partial class Program
    {
        static void Main(string[] args)
        {


            List<IShare> shares = new List<IShare>();
            shares.Add(new Circle { Radius = 5 });
            shares.Add(new Rectangle { Width = 4, Height = 3 });

            foreach (var item in shares)
            {
                Console.WriteLine($"Area = { item.Area()}");
            }


            List<object> MainList = new List<object>();
            MainList.Add("lol");
            MainList.Add(12);
            MainList.Add(new Circle());

            Stack<int> intStack = new Stack<int>();
            intStack.Push(10);
            intStack.Push(20);

            Console.WriteLine(intStack.Pop());

            Stack<string> stringStack = new Stack<string>();
            stringStack.Push("First Data");
            stringStack.Push("Test Data");

            Console.ReadKey();
        }

        class Stack<T>
        {
            private List<T> list = new List<T>();

            public void Push(T item)
            {
                list.Add(item);
            }
            public T Pop()
            {
                if(list.Count > 0)
                {
                    T item = list[list.Count - 1];
                    list.RemoveAt(list.Count - 1);
                    return item;
                }
                else
                {
                    throw new InvalidOperationException("stack is empty");
                }
            }

        }




        
    }

}
