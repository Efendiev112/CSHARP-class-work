﻿using System;

namespace OOP
{
    internal partial class Program
    {
        public class Circle : IShare
        {
            public double Radius { get; set; }
            public double Area()
            {
                return Math.PI * Radius * Radius;
            }
        }



    }

}
