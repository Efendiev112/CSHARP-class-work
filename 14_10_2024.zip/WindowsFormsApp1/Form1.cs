﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        public int answer;
        public int answer2;


        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            answer = 1;
        }
        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            answer = 2;
        }

        private void radioButton4_CheckedChanged(object sender, EventArgs e)
        {
            answer = 4;
        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            answer = 3;
        }

        private void radioButton5_CheckedChanged(object sender, EventArgs e)
        {
            answer = 5;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            switch (answer)
            {
                case 1: labelAnswer.Text = "Ответ верный"; break;
                case 2: labelAnswer.Text = "Ответ неверный"; break;
                case 3: labelAnswer.Text = "Ответ неверный"; break;
                case 4: labelAnswer.Text = "Ответ неверный"; break;
                case 5: labelAnswer.Text = "Ответ неверный"; break;
                default : labelAnswer.Text = "Ответ неверный"; break;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            switch (answer2)
            {
                case 1:
                    if (Convert.ToInt32(textBox1.Text) > 0)
                    {
                        if (Convert.ToInt32(textBox2.Text) > 0)
                        {
                            if (Convert.ToInt32(textBox3.Text) > 0)
                            {
                                labelAnswer2.Text = "Все числа положительные";
                            }
                        }
                    }
                    break;

                case 2:
                    if (Convert.ToInt32(textBox1.Text) > 0)
                    {
                        if (Convert.ToInt32(textBox2.Text) <= 0)
                        {
                            if (Convert.ToInt32(textBox3.Text) <= 0)
                            {
                                labelAnswer2.Text = "Одно число положительное";
                            }
                        }
                    }
                    if (Convert.ToInt32(textBox1.Text) <= 0)
                    {
                        if (Convert.ToInt32(textBox2.Text) > 0)
                        {
                            if (Convert.ToInt32(textBox3.Text) <= 0)
                            {
                                labelAnswer2.Text = "Одно число положительное";
                            }
                        }
                    }

                    if (Convert.ToInt32(textBox1.Text) <= 0)
                    {
                        if (Convert.ToInt32(textBox2.Text) <= 0)
                        {
                            if (Convert.ToInt32(textBox3.Text) > 0)
                            {
                                labelAnswer2.Text = "Одно число положительное";
                            }
                        }
                    }
                    break;

                case 3:
                    if (Convert.ToInt32(textBox1.Text) > 0)
                    {
                        if (Convert.ToInt32(textBox2.Text) > 0)
                        {
                            if (Convert.ToInt32(textBox3.Text) <= 0)
                            {
                                labelAnswer2.Text = "Два числа положительное";
                            }
                        }
                    }
                    if (Convert.ToInt32(textBox1.Text) <= 0)
                    {
                        if (Convert.ToInt32(textBox2.Text) > 0)
                        {
                            if (Convert.ToInt32(textBox3.Text) > 0)
                            {
                                labelAnswer2.Text = "Два числа положительное";
                            }
                        }
                    }
                    if (Convert.ToInt32(textBox1.Text) > 0)
                    {
                        if (Convert.ToInt32(textBox2.Text) <= 0)
                        {
                            if (Convert.ToInt32(textBox3.Text) > 0)
                            {
                                labelAnswer2.Text = "Два числа положительное";
                            }
                        }
                    }
                    break;
                default: labelAnswer2.Text = "Error"; break;
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            answer2 = Convert.ToInt32(textBox1.Text);
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            answer2 = Convert.ToInt32(textBox2.Text);
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            answer2 = Convert.ToInt32(textBox3.Text);
        }
    }


    }
